using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jugador : MonoBehaviour
{
    [SerializeField] float velocidad = 20f;
    [SerializeField] Transform prefabDisparo;
    private float velocidadDisparo = 20f;
    float xInicial, yInicial;

    void Start()
    {
        xInicial = transform.position.x; 
        yInicial = transform.position.y;
    }

    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        transform.Translate(horizontal * velocidad * Time.deltaTime, 0, 0);
        float vertical = Input.GetAxis("Vertical");
        transform.Translate(0, vertical * velocidad * Time.deltaTime, 0);

        if (transform.position.x >= 47.4)
        {
            transform.Translate(-0.1f, 0, 0);
        }

        else if (transform.position.x <= -47.2)
        {
            transform.Translate(+0.1f, 0, 0);
        }

        else if(transform.position.y >= 23)
        {
            transform.Translate(0, -0.1f, 0);
        }

        else if (transform.position.y <= -15.2)
        {
            transform.Translate(0, +0.1f, 0);
        }

        else
        {
            transform.Translate(horizontal * velocidad * Time.deltaTime, vertical * velocidad * Time.deltaTime, 0);
        }

        if (Input.GetButtonDown("Fire1"))
        {
            GetComponent<AudioSource>().Play();

            Transform disparo = Instantiate(prefabDisparo,
                transform.position, Quaternion.identity);

            disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
                new Vector3(0, velocidadDisparo, 0);
        }
    }

    public void Recolocar()
    {
        transform.position = new Vector3(xInicial, yInicial, 0);
    }
}
