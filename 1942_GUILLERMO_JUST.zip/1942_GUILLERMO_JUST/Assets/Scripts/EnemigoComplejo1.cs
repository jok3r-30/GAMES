using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class EnemigoComplejo1 : MonoBehaviour
{
    [SerializeField] Transform prefabDisparoEnemigo;
    private float velocidadDisparo = -13;
    [SerializeField] float velocidadY = 10f;
    private float velocidadX = 10f;

    void Start()
    {
        StartCoroutine(Disparar());
    }

    
    void Update()
    {
        if (transform.position.y >= 17.3f)
        {
            transform.Translate(0, -velocidadY * Time.deltaTime, 0);
        }

        else
        {
            if ((transform.position.x > 47) || (transform.position.x < -47))
            {
                velocidadX = -velocidadX;
            }

            transform.Translate(velocidadX * Time.deltaTime, 0, 0);
        }

        if (transform.position.y < -15.5f)
        {
            Destroy(gameObject);
            FindObjectOfType<GameController>().SendMessage("MatarEnemigo");
        }
    }

    IEnumerator Disparar()
    {
        float pausa = UnityEngine.Random.Range(1.0f, 2.3f);
        yield return new WaitForSeconds(pausa);

        Transform disparo = Instantiate(prefabDisparoEnemigo, new Vector3(transform.position.x + 2f, transform.position.y, 0), Quaternion.identity);
        Transform disparo2 = Instantiate(prefabDisparoEnemigo, new Vector3(transform.position.x - 2, transform.position.y, 0), Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0, velocidadDisparo, 0);
        disparo2.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0, velocidadDisparo, 0);
        StartCoroutine(Disparar());

        if (disparo == true)
        {
            GetComponent<AudioSource>().Play();
        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            FindObjectOfType<GameController>().SendMessage("PerderVidas");
        }
    }
}
