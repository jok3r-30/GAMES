using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisparoNave : MonoBehaviour
{
    [SerializeField] Transform prefabExplosion;
    private AudioSource sonido;

    void Start()
    {
        sonido = GetComponent<AudioSource>();
    }

    
    void Update()
    {
        if (transform.position.y > 24)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "enemigo")
        {
            AudioSource.PlayClipAtPoint(sonido.clip, Camera.main.transform.position);
            Transform explosion = Instantiate(prefabExplosion, other.transform.position, Quaternion.identity);
            Destroy(other.gameObject);
            Destroy(explosion.gameObject, 0.3f);
            Destroy(gameObject);
            FindObjectOfType<GameController>().SendMessage("MatarEnemigo");
        }

        if(other.tag == "boss1")
        {
            Destroy(gameObject);
        }
    }
}
