using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class EnemigoBasico : MonoBehaviour
{
    [SerializeField] float velocidadY = 8;
    [SerializeField] Transform prefabDisparoEnemigo;
    private float velocidadDisparo = -13;
    [SerializeField] Transform prefabExplosion;

    void Start()
    {
        StartCoroutine(Disparar());
    }

    
    void Update()
    {
        transform.Translate(0, -velocidadY * Time.deltaTime, 0);

        if (transform.position.y < -15.5f)
        {
            Destroy(gameObject);
            FindObjectOfType<GameController>().SendMessage("MatarEnemigo");
        }
    }

    IEnumerator Disparar()
    {
        float pausa = UnityEngine.Random.Range(1.0f, 3.0f);
        yield return new WaitForSeconds(pausa);
        
        Transform disparo = Instantiate(prefabDisparoEnemigo, transform.position, Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0, velocidadDisparo, 0);
        StartCoroutine(Disparar());

        if (disparo == true)
        {
            GetComponent<AudioSource>().Play();
        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            Transform explosion = Instantiate(prefabExplosion, collision.transform.position, Quaternion.identity);
            Destroy(explosion.gameObject, 0.3f);
            FindObjectOfType<GameController>().SendMessage("PerderVidas");
        }
    }
}
