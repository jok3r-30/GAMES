using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class masPuntos : MonoBehaviour
{
    [SerializeField] float velocidadY = 6;

    void Update()
    {
        transform.Translate(0, -velocidadY * Time.deltaTime, 0);

        if (transform.position.y < -15.5f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            FindObjectOfType<GameController>().SendMessage("SumarPuntos");
            Destroy(gameObject);
        }
    }
}
