using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    private int puntos;
    private int vidas;
    private int nivelActual;
    public int enemigosRestantes;
    [SerializeField] TMPro.TextMeshProUGUI textoGameOver;
    [SerializeField] TMPro.TextMeshProUGUI textoGanar;
    [SerializeField] TMPro.TextMeshProUGUI texto1UP;
    [SerializeField] TMPro.TextMeshProUGUI texto2UP;
    [SerializeField] TMPro.TextMeshProUGUI textoNivel;
    [SerializeField] TMPro.TextMeshProUGUI textoScore;
    [SerializeField] Boss1 boss;
    [SerializeField] Boss2 boss2;
    [SerializeField] bossFinal boss3;

    void Start()
    {
        textoGameOver.enabled = false;
        textoGanar.enabled = false;
        puntos = FindObjectOfType<GameStatus>().puntos;
        vidas = FindObjectOfType<GameStatus>().vidas;
        enemigosRestantes = FindObjectsOfType<EnemigoBasico>().Length + FindObjectsOfType<EnemigoComplejo1>().Length + FindObjectsOfType<EnemigoComplejo2>().Length;
        nivelActual = FindObjectOfType<GameStatus>().nivelActual;
        textoScore.text = "" + puntos;
        textoNivel.text = "Nivel " + nivelActual;

        if(vidas == 2)
        {
            texto2UP.enabled = false;
        }

        if(vidas == 1)
        {
            texto1UP.enabled = false;
            texto2UP.enabled = false;
        }
    }

    void Update()
    {
        textoScore.text = "" + puntos;
    }

    public void MatarEnemigo()
    {
        puntos += 50;
        FindObjectOfType<GameStatus>().puntos = puntos;
        enemigosRestantes--;

        if(enemigosRestantes <= 0)
        {
            if(SceneManager.GetActiveScene().name == "Nivel1")
            {
                boss.HacerVisible();
            }
            else
            {
                if (SceneManager.GetActiveScene().name == "Nivel2")
                {
                    boss2.HacerVisible();
                }

                else
                {
                    boss3.HacerVisible();
                }
            }
        }
    }

    public void RecogerVida()
    {
        if(vidas < 3)
        {
            vidas++;
            FindObjectOfType<GameStatus>().vidas = vidas;

            if (texto1UP.enabled == false)
                texto1UP.enabled = true;
            if (vidas == 3)
                texto2UP.enabled = true;
        }
    }

    public void SumarPuntos()
    {
        puntos += 200;
        FindObjectOfType<GameStatus>().puntos = puntos;
    }

    private IEnumerator MatarBoss()
    {
        textoGanar.enabled = true;
        Time.timeScale = 0.1f;
        yield return new WaitForSeconds(0.3f);
        Time.timeScale = 1;
        Avanzarnivel();
    }

    public IEnumerator MatarBossFinal()
    {
        Time.timeScale = 0.1f;
        yield return new WaitForSeconds(0.3f);
        Time.timeScale = 1;
        GanarPartida();
    }

    public void PerderVidas()
    {
        if (SceneManager.GetActiveScene().name == "Nivel3")
        {
            vidas--;
            FindObjectOfType<GameStatus>().vidas = vidas;
            FindObjectOfType<Nave2>().SendMessage("Recolocar");
            texto2UP.enabled = false;

            if (vidas <= 1)
            {
                texto1UP.enabled = false;
            }

            if (vidas == 0)
            {
                TerminarPartida();
            }
        }

        else
        {
            vidas--;
            FindObjectOfType<GameStatus>().vidas = vidas;
            FindObjectOfType<Jugador>().SendMessage("Recolocar");
            texto2UP.enabled = false;

            if (vidas <= 1)
            {
                texto1UP.enabled = false;
            }

            if (vidas == 0)
            {
                TerminarPartida();
            }
        }
    }

    public void Avanzarnivel()
    {
        puntos = FindObjectOfType<GameStatus>().puntos;
        vidas = FindObjectOfType<GameStatus>().vidas;
        nivelActual = FindObjectOfType<GameStatus>().nivelActual;
        nivelActual++;
        FindObjectOfType<GameStatus>().nivelActual = nivelActual;


        if (SceneManager.GetActiveScene().name == "Nivel1")
        {
            SceneManager.LoadScene("Nivel2");
        }
        else
        {
            SceneManager.LoadScene("Nivel3");
        }
    }

    public void TerminarPartida()
    {
        GetComponent<AudioSource>().Play();
        textoGameOver.text = "GAME OVER \n\n" +
            "FINAL SCORE: " + puntos;
        textoGameOver.enabled = true;
        FindObjectOfType<GameStatus>().ReiniciarDatos();
        StartCoroutine(VolverAlMenuPrincipal());
    }

    public void GanarPartida()
    {
        textoGanar.text = "JUEGO COMPLETADO!! \n\n" +
            "FINAL SCORE: " + puntos;
        textoGanar.enabled = true;
        FindObjectOfType<GameStatus>().ReiniciarDatos();
        StartCoroutine (VolverAlMenuPrincipal());
    }

    private IEnumerator VolverAlMenuPrincipal()
    {
        Time.timeScale = 0.1f;
        yield return new WaitForSeconds(0.4f);
        Time.timeScale = 1;
        SceneManager.LoadScene("Bienvenida");
    }
}
