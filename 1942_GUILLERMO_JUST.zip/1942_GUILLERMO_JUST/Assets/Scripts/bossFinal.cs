using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bossFinal : MonoBehaviour
{
    [SerializeField] List<Transform> myPoints;
    [SerializeField] float velocidad = 14f;
    [SerializeField] Transform prefabExplosionBoss;
    private Vector3 siguientePos;
    public byte numeroSiguientePos = 0;
    public float distanciaCambio = 0.2f;

    [SerializeField] Transform prefabDisparoBoss;
    public float velocidadDisparo = -18;
    public int counter = 0;

    public void Start()
    {
        gameObject.SetActive(false);
        siguientePos = myPoints[0].position;
    }


    public void Update()
    {
        transform.position = Vector3.MoveTowards(
            transform.position,
            siguientePos,
            velocidad * Time.deltaTime);

        if (Vector3.Distance(transform.position, siguientePos) < distanciaCambio)
        {
            numeroSiguientePos++;
            if (numeroSiguientePos >= myPoints.Count)
            {
                numeroSiguientePos = 0;
            }

            siguientePos = myPoints[numeroSiguientePos].position;
        }
    }

    public IEnumerator Disparar()
    {
        float pausa = UnityEngine.Random.Range(1.7f, 2.8f);
        yield return new WaitForSeconds(pausa);

        Transform disparo = Instantiate(prefabDisparoBoss, new Vector3(transform.position.x + 7.5f, transform.position.y, 0), Quaternion.identity);
        Transform disparo2 = Instantiate(prefabDisparoBoss, new Vector3(transform.position.x - 7.5f, transform.position.y, 0), Quaternion.identity);
        Transform disparo3 = Instantiate(prefabDisparoBoss, transform.position, Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0, velocidadDisparo, 0);
        disparo2.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0, velocidadDisparo, 0);
        disparo3.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0, velocidadDisparo - 2, 0);

        StartCoroutine(Disparar());

        if (disparo == true)
        {
            GetComponent<AudioSource>().Play();
        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            FindObjectOfType<GameController>().SendMessage("PerderVidas");
        }

        if (collision.tag == "DisparoNave")
        {
            counter++;
            Destroy(collision.gameObject);
            if (counter >= 25)
            {
                Transform explosionBoss = Instantiate(prefabExplosionBoss, collision.transform.position, Quaternion.identity);
                Destroy(explosionBoss.gameObject, 0.5f);
                FindObjectOfType<GameController>().SendMessage("MatarBossFinal");
                Destroy(gameObject);
            }
        }
    }

    public void HacerVisible()
    {
        gameObject.SetActive(true);
        StartCoroutine(Disparar());
    }
}
