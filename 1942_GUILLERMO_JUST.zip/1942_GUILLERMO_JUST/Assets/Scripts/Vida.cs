using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vida : MonoBehaviour
{
    private AudioSource sonido;
    [SerializeField] float velocidadY = 8;

    void Start()
    {
        sonido = GetComponent<AudioSource>();
    }

    void Update()
    {
        transform.Translate(0, -velocidadY * Time.deltaTime, 0);

        if (transform.position.y < -15.5f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            FindObjectOfType<GameController>().SendMessage("RecogerVida");
            AudioSource.PlayClipAtPoint(sonido.clip, Camera.main.transform.position);
            Destroy(gameObject);
        }
    }
}
