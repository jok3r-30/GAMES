using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomba : MonoBehaviour
{
    [SerializeField] float velocidadY = 8;
    [SerializeField] Transform prefabExplosion;
    private AudioSource sonido;

    void Start()
    {
        sonido = GetComponent<AudioSource>();
    }

    void Update()
    {
        transform.Translate(0, -velocidadY * Time.deltaTime, 0);

        if (transform.position.y < -15.5f)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            AudioSource.PlayClipAtPoint(sonido.clip, Camera.main.transform.position);
            Transform explosion = Instantiate(prefabExplosion, collision.transform.position, Quaternion.identity);
            Destroy(explosion.gameObject, 0.3f);
            FindObjectOfType<GameController>().SendMessage("PerderVidas");
            Destroy(gameObject);
        }
    }
}
