using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss1 : MonoBehaviour
{
    [SerializeField] List<Transform> myPoints;
    [SerializeField] float velocidad = 5f;
    [SerializeField] Transform prefabExplosionBoss;
    private Vector3 siguientePos;
    public byte numeroSiguientePos = 0;
    public float distanciaCambio = 0.2f;

    [SerializeField] Transform prefabDisparoBoss;
    public float velocidadDisparo = -13;
    public int counter = 0;

    public void Start()
    {
        gameObject.SetActive(false);
        siguientePos = myPoints[0].position;
    }


    public void Update()
    {
        transform.position = Vector3.MoveTowards(
            transform.position,
            siguientePos,
            velocidad * Time.deltaTime);

        if (Vector3.Distance(transform.position, siguientePos) < distanciaCambio)
        {
            numeroSiguientePos++;
            if (numeroSiguientePos >= myPoints.Count)
            {
                numeroSiguientePos = 0;
            }

            siguientePos = myPoints[numeroSiguientePos].position;
        }
    }

    public IEnumerator Disparar()
    {
        float pausa = UnityEngine.Random.Range(2.0f, 5.0f);
        yield return new WaitForSeconds(pausa);

        Transform disparo = Instantiate(prefabDisparoBoss, transform.position, Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0, velocidadDisparo, 0);

        StartCoroutine(Disparar());

        if (disparo == true)
        {
            GetComponent<AudioSource>().Play();
        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            FindObjectOfType<GameController>().SendMessage("PerderVidas");
        }

        if (collision.tag == "DisparoNave")
        {
            counter++;
            Destroy(collision.gameObject);
            if (counter >= 12)
            {
                Transform explosionBoss = Instantiate(prefabExplosionBoss, collision.transform.position, Quaternion.identity);
                Destroy(explosionBoss.gameObject, 0.6f);
                FindObjectOfType<GameController>().SendMessage("MatarBoss");
                Destroy(gameObject);
            }
        }
    }

    public void HacerVisible()
    {
        gameObject.SetActive(true);
        StartCoroutine(Disparar());
    }
}
